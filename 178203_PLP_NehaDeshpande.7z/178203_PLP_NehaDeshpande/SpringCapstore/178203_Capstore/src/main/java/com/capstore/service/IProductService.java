package com.capstore.service;

import java.util.List;



import com.capstore.bean.Product;


public interface IProductService {

	// fetch similar product by type
	public Iterable<Product> findBycategory(String productcat);
	Product addproduct(Product product);
	Iterable<Product> getAllProduct();
	public Iterable<Product> findByBrand(String brand);
	public Iterable<Product> findByName(String brand);
	/*public List findAll();*/
	
}
