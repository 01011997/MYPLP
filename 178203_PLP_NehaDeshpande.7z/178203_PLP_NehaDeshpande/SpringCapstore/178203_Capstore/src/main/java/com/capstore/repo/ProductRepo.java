package com.capstore.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.Product;



public interface ProductRepo extends CrudRepository<Product, Integer> {
	
	public Iterable<Product> findByname(String productcat);
	public Iterable<Product> findByBrand(String brand);
	public Iterable<Product> findByName(String name);
	/* List findAll();*/
}
