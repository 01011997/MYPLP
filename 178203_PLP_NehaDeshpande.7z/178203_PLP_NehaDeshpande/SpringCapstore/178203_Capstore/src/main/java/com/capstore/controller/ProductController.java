
package com.capstore.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.capstore.bean.Product;
import com.capstore.service.IProductService;


@CrossOrigin(origins = "*")
@RequestMapping({"/api"})
@RestController
public class ProductController {

	@Autowired
	IProductService service;
	@PostMapping(path = "/addproduct", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Product> addproduct(@RequestBody Product product) {
		return new ResponseEntity<Product>(service.addproduct(product), HttpStatus.OK);
	}
	
	@GetMapping(path = "/products", produces = "application/json")
	public ResponseEntity<Iterable<Product>> getAllProduct() {
		return new ResponseEntity<Iterable<Product>>(service.getAllProduct(), HttpStatus.OK);
	}
	
	@GetMapping(path = "/getbycategory/{productcat}", produces = "application/json")
	public Iterable<Product> getSimilarProductsByCategory(@PathVariable("productcat") String productcat) {
		return service.findBycategory(productcat);
	}
	@GetMapping(path = "/getbybrand/{brand}", produces = "application/json")
	public Iterable<Product> getSimilarProductsByBrand(@PathVariable("brand") String brand) {
		return service.findByBrand(brand);
	}
	
	@GetMapping(path = "/getbyname/{name}", produces = "application/json")
	public Iterable<Product> getSimilarProductsByName(@PathVariable("name") String name) {
		return service.findByName(name);
		
	}
	/*@GetMapping 
	  public List findAll(){
        return service.findAll();
    }*/
}
