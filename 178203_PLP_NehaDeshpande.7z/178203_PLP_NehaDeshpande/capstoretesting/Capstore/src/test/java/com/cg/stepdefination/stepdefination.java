package com.cg.stepdefination;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.cg.broserfactory.BrowserFactory;
import com.cg.cap.Capstore;


import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdefination {

	

	WebDriver driver;
	WebElement searchBox;
	Capstore page;
	
	@Before
	public void setUp() {

		driver = BrowserFactory.startBrowser("chrome",
				"http://localhost:4200/");
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
	}

	@After
	public void tearDown() {
		driver.close();
	}
	
	
	

@Given("^User is on Welcome to Capstore page$")
public void user_is_on_Welcome_to_Capstore_page() throws Exception {
	page = PageFactory.initElements(driver, Capstore.class);
	Thread.sleep(2000);;
}

@Then("^Verify the title of the page$")
public void verify_the_title_of_the_page() throws Exception {
	assertEquals("Welcome to CapStore!", page.getGetTitle());
	if (page.getGetTitle().equals("Welcome to CapStore!")) {
		System.out.println("Heading matched");
	} else {
		System.out.println("Heading not matched");
	}
}

@When("^User click on button List Of Product$")
public void user_click_on_button_List_Of_Product() throws Exception {
    page.getListOfProduct();
    Thread.sleep(5000);
}

/*@Given("^User is on Welcome to Capstore Page$")
public void user_is_on_Welcome_to_Capstore_Page() throws Exception {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}*/

/*@When("^User Click On View Similar Product$")
public void user_Click_On_View_Similar_Product() throws Exception {
  
}*/

@When("^User click on button List Of Brands$")
public void user_click_on_button_List_Of_Brands() throws Exception {
	 page.getListOfBrand();
	 Thread.sleep(5000);
}


}
