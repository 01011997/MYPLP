package com.cg.cap;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Capstore 
{
	@FindBy(how=How.NAME, using="cap")
	@CacheLookup
	private WebElement getTitle;
	
	public void getViewSimilarProduct() {
		this.ViewSimilarProduct.click();
	}
	

	@FindBy(how=How.NAME, using="product")
	@CacheLookup
	private WebElement ListOfProduct;
	@FindBy(how=How.NAME, using="brand")
	@CacheLookup
	private WebElement ListOfBrand;
	
	@FindBy(how=How.NAME, using="similar")
	@CacheLookup
	private WebElement ViewSimilarProduct;
	
	public String getGetTitle() {
		return getTitle.getText();
	}
	public void getListOfProduct() {
		this.ListOfProduct.click();;
	}
	
	public void getListOfBrand() {
		this.ListOfBrand.click();
	}
	
	public void setGetTitle(WebElement getTitle) {
		this.getTitle = getTitle;
	}




	

	
}
