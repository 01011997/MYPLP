import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SimilarproductComponent } from './similarproduct/similarproduct.component';
import { ProductService } from './product.service';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from "@angular/common/http";
import { SimilarbrandComponent } from './similarbrand/similarbrand.component';



@NgModule({
  declarations: [
    AppComponent,
    SimilarproductComponent,
    SimilarbrandComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
