import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Product } from './similarproduct';
import { CodegenComponentFactoryResolver } from '@angular/core/src/linker/component_factory_resolver';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:HttpClient) {
    this.getProduct().subscribe(data=>this.products=data)
    this.getProduct1().subscribe(data=>this.prod=data)
    this.getProduct2().subscribe(data=>this.TV=data)
    this.getLG().subscribe(data=>this.LG=data)
    this.getSamsung().subscribe(data=>this.Samsung=data)
    this.getfashion().subscribe(data=>this.fashion=data)
    
   }

  products:Product[]=[];
  getProduct():any{
    return this.http.get<Product>("http://localhost:8087/api/getbyname/AC");
  }
  prod:Product[];
  getProduct1():any{
    return this.http.get<Product>("http://localhost:8087/api/getbyname/Mobile");
  }
  /* getProduct1():any{
    return this.http.get<Product>("http")
  } */
  TV:Product[];
  getProduct2():any{
    return this.http.get<Product>("http://localhost:8087/api/getbyname/TV");
  }
  fashion:Product[];
  getfashion():any{
    return this.http.get<Product>("http://localhost:8087/api/getbycategory/Fashion");
  }
  LG:Product[];
  getLG():any{
    return this.http.get<Product>("http://localhost:8087/api/getbybrand/LG");
  }
  Samsung:Product[];
  getSamsung():any{
    return this.http.get<Product>("http://localhost:8087/api/getbybrand/Samsung");
  }
  
  getData():Product[]{
    console.log(this.products);
    return this.products;
  }
  getData1():Product[]{
    console.log(this.prod);
    return this.prod;
  }
  getTV():Product[]{
    console.log(this.TV);
    return this.TV;
  }
  getclothing():Product[]
  {
    console.log(this.fashion);
    return this.fashion;
  }
  getBrand():Product[]
  {
    console.log(this.Samsung);
    return this.Samsung;
  }
  getBrand1():Product[]
  {
    console.log(this.LG);
    return this.LG;
  }
  
}
