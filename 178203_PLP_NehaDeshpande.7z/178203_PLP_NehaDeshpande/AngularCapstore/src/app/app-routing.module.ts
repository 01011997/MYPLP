import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SimilarproductComponent } from './similarproduct/similarproduct.component';
import { SimilarbrandComponent } from './similarbrand/similarbrand.component';


const routes: Routes = [
{
  path:'products',component:SimilarproductComponent
},
{
  path:'brand',component:SimilarbrandComponent
},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
