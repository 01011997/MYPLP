import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { Product } from '../similarproduct';

@Component({
  selector: 'app-similarproduct',
  templateUrl: './similarproduct.component.html',
  styleUrls: ['./similarproduct.component.css']
})
export class SimilarproductComponent implements OnInit {
  products:Product[];
 
  constructor( private service:ProductService) { }

  ngOnInit() {
   
  }
  getData()
  {
    this.products=<Product[]>this.service.getData();
    
   // console.log(this.products);
  }
getData1()
{
  this.products=<Product[]>this.service.getData1();
}
getTV()
{
  this.products=<Product[]>this.service.getTV();
}
getclothing()
{
  this.products=<Product[]>this.service.getclothing();
}
}
