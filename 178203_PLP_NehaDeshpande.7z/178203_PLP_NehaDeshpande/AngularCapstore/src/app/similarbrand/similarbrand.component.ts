import { Component, OnInit } from '@angular/core';
import { Product } from '../similarproduct';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-similarbrand',
  templateUrl: './similarbrand.component.html',
  styleUrls: ['./similarbrand.component.css']
})
export class SimilarbrandComponent implements OnInit {
  products:Product[];
 
  constructor(private service:ProductService) { }

  ngOnInit() {
  }
  getBrand()
  {
    this.products=<Product[]>this.service.getBrand();
    
   // console.log(this.products);
  }
  getBrand1()
{
  this.products=<Product[]>this.service.getBrand1();
}
}
