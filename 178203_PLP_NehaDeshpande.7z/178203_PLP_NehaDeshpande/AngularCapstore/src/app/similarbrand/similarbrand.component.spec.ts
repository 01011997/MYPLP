import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SimilarbrandComponent } from './similarbrand.component';

describe('SimilarbrandComponent', () => {
  let component: SimilarbrandComponent;
  let fixture: ComponentFixture<SimilarbrandComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SimilarbrandComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SimilarbrandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
